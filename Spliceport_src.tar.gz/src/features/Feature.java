package features;

public interface Feature {
	//public boolean isFound();
	
	public double getScore();
	
	public int getID();
	

}
